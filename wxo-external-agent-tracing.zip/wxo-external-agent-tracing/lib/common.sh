#!/usr/bin/env bash
# =============================================================================
# lib/common.sh  —  Shared shell helpers used by all platform flows
#
# Sourced by aws/lib/flow_harness.sh, aws/lib/flow_runtime.sh, and
# vertex/lib/flow_selfhosted.sh.  Never executed directly.
# =============================================================================

# ── wait_ready ────────────────────────────────────────────────────────────────
# Poll a shell command until it returns a given expected value, or times out.
#
# Usage:
#   wait_ready <label> <max_attempts> <sleep_sec> <expected_value> <cmd...>
#
# Arguments:
#   label          Human-readable name for log output (e.g. "Harness", "Runtime")
#   max_attempts   Maximum number of poll iterations (e.g. 30)
#   sleep_sec      Seconds to sleep between polls (e.g. 10)
#   expected_value The stdout value that signals success (e.g. "READY" or "True")
#   cmd...         Command + args to run; its stdout is compared to expected_value
#
# Returns 0 on success, 1 on timeout.
#
# Example:
#   wait_ready "AgentCore Harness" 30 10 "READY" \
#       aws bedrock-agentcore-control get-harness \
#           --harness-id "${AGENT_REF}" --region "${AWS_REGION}" \
#           --query "harness.status" --output text
# =============================================================================
wait_ready() {
    local label="$1" max="$2" delay="$3" expected="$4"
    shift 4   # remaining args are the command to run

    local status i
    for i in $(seq 1 "${max}"); do
        status=$("$@" 2>/dev/null || echo "UNKNOWN")
        if [ "${status}" = "${expected}" ]; then
            echo "  ✓ ${label} ${expected}"
            return 0
        fi
        printf "  ... %s (%d/%d)\n" "${status}" "${i}" "${max}"
        sleep "${delay}"
    done

    echo "  ✗ Timed out waiting for ${label} to reach '${expected}' (${max} attempts × ${delay}s)"
    return 1
}
