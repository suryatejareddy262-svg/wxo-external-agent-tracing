# WXO Agent Analytics Tracing — Unified Multi-Cloud Repo

Sends traces from agents running on **AWS**, **Azure**, and **Google Cloud (Vertex AI)** to **IBM watsonx Orchestrate (WXO) Agent Analytics** using OpenTelemetry.

All three platforms are wired through a **single entrypoint** (`wire_agent.sh`) and per-platform config files under `config/`.

---

## Supported platforms and flows

| Platform | Flow | Mechanism |
|---|---|---|
| **AWS AgentCore — Harness** | `--aws --harness` | Inject `OTEL_*` env vars into the AWS-managed Harness image. The pre-installed ADOT SDK emits spans → API GW → Lambda → WXO. No image change. |
| **AWS AgentCore — Runtime** | `--aws --runtime` | Patch your ECR image with `sitecustomize.py`. Python auto-imports it at startup and posts spans directly to WXO. |
| **Azure AI Foundry — kind:prompt** | `--azure --prompt` | Azure Function App polls `AppGenAIContent` in Log Analytics every 30 s and forwards spans to WXO. One deployment covers all prompt agents. |
| **Azure AI Foundry — kind:hosted** | `--azure --hosted` | Bundle `sitecustomize.py` into a new agent source version. Python auto-imports it at startup — before `main.py`. |
| **Vertex AI — Reasoning Engine** | `--vertex --reasoning-engine` | WXO trace code embedded directly in `query()` via cloudpickle. No container access needed. |
| **Vertex AI — Self-hosted container** | `--vertex --selfhosted` | Patch your Cloud Run / GKE image with `sitecustomize.py`. Python auto-imports it at startup and posts spans directly to WXO. |

---

## Repository structure

```
wxo-external-agent-tracing/
├── wire_agent.sh                ← Top-level entrypoint — dispatches to aws/azure/vertex
│
├── config/
│   ├── shared.env.example       ← WXO API key + token URL (copy → shared.env)
│   ├── aws.env.example          ← AWS account + WXO agent map (copy → aws.env)
│   ├── azure.env.example        ← Azure subscription + WXO agent map (copy → azure.env)
│   └── vertex.env.example       ← GCP project + WXO agent map (copy → vertex.env)
│
├── shared/
│   └── sitecustomize.py         ← CANONICAL sitecustomize.py — edit only here
│
├── container_hook/
│   └── Dockerfile               ← One-line patch layer: copies sitecustomize.py → site-packages
│
├── aws/
│   ├── wire_agent.sh            ← AWS entrypoint
│   ├── ssm_params.sh            ← Store WXO credentials in SSM (run once)
│   ├── agentcore_trace_hook.py  ← Lambda: decode OTLP protobuf + forward to WXO
│   ├── agent-patch/
│   │   └── Dockerfile           ← Builds patched ECR image (runtime flow)
│   └── lib/
│       ├── infra.sh             ← Lambda + API GW provisioning
│       ├── flow_harness.sh      ← Harness flow (env vars only)
│       └── flow_runtime.sh      ← Runtime flow (image patch)
│
├── azure/
│   ├── wire_agent.py            ← Azure entrypoint (Python)
│   ├── function_app.py          ← Azure Function App: polls Log Analytics → WXO
│   ├── Dockerfile.patch         ← Optional: patch an existing container image
│   ├── requirements.txt         ← azure-functions (for the Function App)
│   ├── host.json                ← Function App runtime config
│   └── local.settings.json      ← Local dev settings (placeholder values)
│
└── vertex/
    ├── wire_agent.sh            ← Vertex entrypoint
    ├── lib/
    │   └── flow_selfhosted.sh   ← Self-hosted container flow
    └── reasoning_engine/
        └── deploy.py            ← Reasoning Engine deploy + patch
```

---

## Quick start

### Step 1 — Copy and fill in config files

```bash
cd wxo-external-agent-tracing

cp config/shared.env.example  config/shared.env  && vi config/shared.env
cp config/aws.env.example     config/aws.env     && vi config/aws.env     # AWS only
cp config/azure.env.example   config/azure.env   && vi config/azure.env   # Azure only
cp config/vertex.env.example  config/vertex.env  && vi config/vertex.env  # Vertex only
```

Minimum required in `config/shared.env`:

```bash
export API_KEY="<your-wxo-api-key>"
export TOKEN_URL="https://account-iam.platform.saas.ibm.com/api/2.0/apikeys/token"
```

Each platform file holds its own `WXO_TENANT_ID`, `WXO_OTEL_EXPORT_URL`, and `WXO_AGENT_MAP`.  See the `.example` files for the full schema.

### Step 2 — Make scripts executable

```bash
chmod +x wire_agent.sh aws/wire_agent.sh aws/ssm_params.sh vertex/wire_agent.sh
```

### Step 3 — Wire your agents

```bash
# ── AWS ───────────────────────────────────────────────────────────────────────
./aws/ssm_params.sh              # run once — stores WXO credentials in SSM
./wire_agent.sh --aws --harness  # Flow A: Harness (env vars only)
./wire_agent.sh --aws --runtime  # Flow B: Runtime (image patch)

# ── Azure ─────────────────────────────────────────────────────────────────────
az login
./wire_agent.sh --azure --prompt  # Flow A: kind:prompt (Function App)
./wire_agent.sh --azure --hosted  # Flow B: kind:hosted (sitecustomize.py)

# ── Vertex ────────────────────────────────────────────────────────────────────
gcloud auth login
./wire_agent.sh --vertex --reasoning-engine  # Reasoning Engine
./wire_agent.sh --vertex --selfhosted        # Self-hosted container
```

All commands support `--dry-run` to preview changes without deploying.

---

## Platform details

### AWS AgentCore

Two flows controlled by `--harness` / `--runtime`:

#### Flow A — Harness (configuration-driven)

```mermaid
flowchart LR
    A["Harness agent<br/>AWS-managed image"] --> B["ADOT SDK<br/>OTLP/HTTP protobuf"]
    B --> C["API Gateway"]
    C --> D["Lambda collector<br/>decode + enrich"]
    D --> E["WXO Agent Analytics"]
```

No image changes. The ADOT SDK is pre-installed in AWS-managed images.
`wire_agent.sh` injects `OTEL_*` env vars into the Harness and stores agent identity in SSM.

#### Flow B — Runtime (image-driven)

```mermaid
flowchart LR
    A["Runtime agent<br/>custom ECR image"] --> B["sitecustomize.py<br/>startup hook"]
    B --> C["Agent HTTP handler"]
    B --> D["WXO endpoint<br/>direct POST"]
```

`wire_agent.sh` builds a patched ECR image and updates the Runtime.
`sitecustomize.py` is the only addition — no user code changes.

**Prerequisites:** AWS CLI authenticated, Docker running (runtime only), `ssm_params.sh` run once.

---

### Azure AI Foundry

Two flows controlled by `--prompt` / `--hosted`:

#### Flow A — kind:prompt (Function App polling)

```mermaid
flowchart LR
    A["Prompt agents"] -->|auto-telemetry| B["App Insights /\nLog Analytics"]
    B -->|KQL every 30s| C["Azure Function App"]
    C -->|OTLP spans| D["WXO Agent Analytics"]
```

`wire_agent.py --prompt` deploys a Function App that polls Log Analytics every 30 s.
One deployment covers **all** prompt agents in the workspace.

#### Flow B — kind:hosted (sitecustomize.py injection)

```mermaid
flowchart LR
    A["wire_agent.py --hosted"] -->|inject sitecustomize.py| B["New agent version zip"]
    B -->|create_version_from_code| C["Foundry managed container"]
    C -->|spans at runtime| D["WXO Agent Analytics"]
```

`wire_agent.py --hosted` creates a new agent version bundled with `sitecustomize.py`.
The previous version is untouched — Foundry keeps full version history.

#### Agent source resolution (Flow B)

`wire_agent.py --hosted` needs your agent's source files to build the deployment zip.
It resolves them in this order — the first match wins:

| Priority | Source | Behaviour |
|---|---|---|
| **1** | `AGENT_SOURCE_DIR` (env var) | Any local directory — **all files zipped automatically** |
| **2** | `azure/agents/<foundry-agent-name>/` | Per-agent folder in this repo — **all files zipped** |
| **3** | `azure/agent/` | Legacy single-agent fallback — **all files zipped** |
| **4** | `AGENT_SOURCE_URL` — GitHub raw URL | Contents API lists the directory; **all files downloaded** |
| **5** | `AGENT_SOURCE_URL` — other HTTP(S) URL | `main.py` + `requirements.txt` fetched only |
| **6** | Built-in GitHub mirror | Microsoft Foundry sample via Contents API — **all files** |

**Local directories (options 1–3): all files included automatically**

No file list is needed. Every file in the directory is zipped — `main.py`, `requirements.txt`, tool files, helper modules, proto stubs, anything. Only `sitecustomize.py` is excluded (it is injected separately by the tool).

```bash
# Option 1 — agent lives outside this repo:
export AGENT_SOURCE_DIR="/absolute/path/to/my-agent"
# or relative to where you run the script:
export AGENT_SOURCE_DIR="../../my-agents/my-agent"

# Option 2 — agent is in this repo (no env var needed):
#   Drop all files into:  azure/agents/<your-foundry-agent-name>/
#   wire_agent.py detects it automatically.
```

**Remote fetch (options 4–6): triggered only when no local directory is found**

For **GitHub raw URLs** (`raw.githubusercontent.com`), the tool calls the GitHub Contents API to list the directory and downloads **every file** — no hardcoded file list. For other URLs, only `main.py` and `requirements.txt` are fetched (HTTP servers have no standard directory-listing protocol).

```bash
# config/azure.env

# GitHub raw URL — ALL files in the directory are fetched automatically:
export AGENT_SOURCE_URL="https://raw.githubusercontent.com/<org>/<repo>/<branch>/path/to/agent"

# Other HTTP(S) server — main.py + requirements.txt only:
export AGENT_SOURCE_URL="https://<account>.blob.core.windows.net/<container>/<agent-folder>"

# Leave unset → Microsoft Foundry GitHub mirror (also fetches all files via Contents API).

# Optional: GitHub PAT to avoid the 60 req/h unauthenticated rate limit.
# Required for private repos. Needs read:contents scope.
export GITHUB_TOKEN="ghp_..."
```

**Additional flags:**
```bash
python3 azure/wire_agent.py --hosted --revert          # remove tracing
python3 azure/wire_agent.py --prompt --publish-only    # redeploy code only
python3 azure/wire_agent.py --prompt --dry-run
python3 azure/wire_agent.py --hosted --dry-run
```

**Prerequisites:** `az` CLI authenticated, `func` CLI (Flow A only), `azure-ai-projects` SDK (Flow B only).

---

### Vertex AI

Two flows controlled by `--reasoning-engine` / `--selfhosted`:

#### Flow A — Reasoning Engine (bytecode injection)

```
Caller → Vertex AI Reasoning Engine (Google-managed container)
           └─ query() with embedded WXO trace code
                └─ POST span to WXO_OTEL_EXPORT_URL
```

`wire_agent.sh --reasoning-engine` re-uploads the agent bytecode with WXO tracing frozen in.
No new engine is created — updates the existing one via `engine.update()`.

#### Flow B — Self-hosted container (image patch)

```mermaid
flowchart LR
    A["wire_agent.sh --selfhosted"] -->|inject sitecustomize.py| B["Patched image"]
    B -->|docker push| C["Artifact Registry"]
    C -->|gcloud run deploy| D["Cloud Run / GKE"]
    D -->|spans at runtime| E["WXO Agent Analytics"]
```

`wire_agent.sh --selfhosted` builds a patched image and deploys to Cloud Run (or just pushes for GKE).

**Prerequisites:** `gcloud` authenticated, Docker running.

---

## The sitecustomize.py hook

`shared/sitecustomize.py` is the **single canonical source** for the universal trace hook.
The `container_hook/Dockerfile` copies it directly from `shared/` — there are no separate platform copies to keep in sync.

It patches all major Python HTTP / RPC frameworks automatically at Python startup — no changes to agent code required:

| Framework | Mechanism | Notes |
|---|---|---|
| `http.server` | `BaseHTTPRequestHandler.do_POST` patch | stdlib, works with wsgiref dev server |
| **Starlette / FastAPI** | `BaseHTTPMiddleware` injected at app init | ASGI; FastAPI subclasses Starlette transparently |
| **Flask** | `Flask.wsgi_app` wrapper | works with any WSGI server (Gunicorn, uWSGI, waitress) |
| **Django** | `WSGIHandler.__call__` patch | covers `runserver`, Gunicorn, uWSGI, mod_wsgi |
| **Generic WSGI** | module-level `app`/`application` `__call__` wrap | fallback for Falcon, Bottle, Pyramid, raw wsgiref |
| **Tornado** | `tornado.web.Application.__call__` wrap | captures response via `connection.finish` hook |
| **aiohttp** | `aiohttp.web.Application` middleware injection | prepended at `__init__`; deferred GC walk handles pre-existing apps |
| **gRPC** | `grpc.ServerInterceptor` injected into `grpc.server()` | all four call types: unary-unary, server-streaming, client-streaming, bidi-streaming |

All config comes from env vars — no hardcoded values.

A deferred background thread re-runs all patches every 2 s for 30 s after startup, catching apps constructed after `sitecustomize.py` first runs (e.g. lazy app creation, hot reload).

Thread-local guards (`_IN_TRACE_POST`, `_IN_REQUEST_TRACE`) prevent the hook from tracing its own outbound OTLP POST or double-posting when multiple framework layers are stacked.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| No traces in WXO | Missing env vars | Check `WXO_TENANT_ID`, `API_KEY`, `WXO_OTEL_EXPORT_URL` in your platform config |
| `WXO_OTEL_EXPORT_URL not set` | Config not sourced | Confirm `config/shared.env` + platform env are loaded |
| AWS: No trace after Harness update | ADOT not sending | Check Lambda logs: `aws logs tail /aws/lambda/wxo-agentcore-trace-hook --follow` |
| AWS: Runtime image not patched | Docker not running | Start Docker Desktop, re-run `--runtime` |
| Azure: Function App not publishing | `func` CLI missing | `brew install azure-functions-core-tools@4` |
| Azure: Hosted agent version stuck | Provisioning delay | Poll output shows status — wait up to 10 min |
| Vertex: Reasoning Engine not updating | SDK not installed | `pip install "google-cloud-aiplatform[agent_engines]>=1.60.0" cloudpickle` |
| Vertex: selfhosted — no hook logs | Image not pushed | Re-run `--selfhosted` to rebuild and push |

---

## Security

- **Never commit real credentials.** `config/shared.env`, `config/aws.env`, `config/azure.env`, and `config/vertex.env` are all in `.gitignore`.
- AWS: credentials are stored in SSM Parameter Store (SecureString).
- Azure: credentials are stored as Function App Settings / agent version env vars.
- Vertex: credentials are injected as Cloud Run / Reasoning Engine env vars — use GCP Secret Manager for production.
