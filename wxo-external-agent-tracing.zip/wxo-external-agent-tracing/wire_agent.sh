#!/usr/bin/env bash
# =============================================================================
# wire_agent.sh  —  Unified WXO Agent Analytics Tracing Setup
#
# Covers all three cloud platforms from a single entrypoint.
#
# Usage:
#   ./wire_agent.sh --aws    [--harness|--runtime]              [--dry-run]
#   ./wire_agent.sh --azure  [--prompt|--hosted] [--revert]     [--dry-run] [--publish-only]
#   ./wire_agent.sh --vertex [--reasoning-engine|--selfhosted]  [--dry-run]
#
# Agent input (ALL platforms):
#   WXO_AGENT_MAP in config/<platform>.env — the only supported input.
#   One entry = one agent.  Many entries = wire all in one run.
#   Each entry carries the AGENT_REF (or agent key) → WXO identity mapping.
#   See config/aws.env.example, config/azure.env.example, config/vertex.env.example
#   for the per-platform JSON schema.
#
# AWS flows (AGENT_TYPE in config/aws.env):
#   --harness  → Flow A: env vars only, no Docker, no image change
#   --runtime  → Flow B: sitecustomize.py image patch
#
# Azure flows:
#   --prompt   → Flow A: Azure Function App polls Log Analytics every 30s
#   --hosted   → Flow B: sitecustomize.py bundled into agent version (default)
#
# Vertex flows:
#   --selfhosted       → sitecustomize.py injected into container (default)
#   --reasoning-engine → WXO tracing embedded in Reasoning Engine query()
#
# Pre-requisites:
#   AWS:    AWS CLI authenticated; Docker (--runtime only); ssm_params.sh run once
#   Azure:  az CLI authenticated; func CLI (--prompt); azure-ai-projects (--hosted)
#   Vertex: gcloud authenticated; Docker (--selfhosted)
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_DIR="${SCRIPT_DIR}/config"

# ── Detect platform early (needed to pick the right config file) ──────────────
PLATFORM=""
DRY_RUN=0
PASSTHROUGH_ARGS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --aws)    PLATFORM="aws" ;;
        --azure)  PLATFORM="azure" ;;
        --vertex) PLATFORM="vertex" ;;
        --dry-run) DRY_RUN=1; PASSTHROUGH_ARGS+=("--dry-run") ;;
        --help|-h)
            sed -n '2,/^set -/p' "$0" | grep '^#' | sed 's/^# \{0,2\}//'
            exit 0
            ;;
        *) PASSTHROUGH_ARGS+=("$1") ;;
    esac
    shift
done

if [ -z "${PLATFORM}" ]; then
    echo "  ✗ Platform not specified. Use --aws, --azure, or --vertex."
    echo ""
    echo "  Run $0 --help for usage."
    exit 1
fi

# ── Load config: shared.env first, then <platform>.env ───────────────────────
# Only the platform you're running is loaded — no cross-platform variable bleed.
_shared="${CONFIG_DIR}/shared.env"
_platform_cfg="${CONFIG_DIR}/${PLATFORM}.env"

if [ ! -f "${_shared}" ]; then
    echo "  ✗ config/shared.env not found."
    echo "    cp config/shared.env.example config/shared.env  and fill in your WXO credentials."
    exit 1
fi
if [ ! -f "${_platform_cfg}" ]; then
    echo "  ✗ config/${PLATFORM}.env not found."
    echo "    cp config/${PLATFORM}.env.example config/${PLATFORM}.env  and fill in your values."
    exit 1
fi

set -a
source "${_shared}"
source "${_platform_cfg}"
set +a

# ── Validate shared WXO credentials (account-wide — must be in shared.env) ───
_wxo_missing=0
for _var in API_KEY TOKEN_URL; do
    _val="${!_var:-}"
    if [ -z "${_val}" ] || [[ "${_val}" == *"<"* ]]; then
        echo "  ✗ ${_var} is not set in config/shared.env"
        _wxo_missing=1
    fi
done
if [ "${_wxo_missing}" -eq 1 ]; then
    echo ""
    echo "  Edit config/shared.env and re-run."
    exit 1
fi

# ── Validate per-platform defaults (must be in <platform>.env) ───────────────
# WXO_TENANT_ID and WXO_OTEL_EXPORT_URL are the global fallback defaults used
# when a WXO_AGENT_MAP entry does not specify its own tenant routing.
# They are intentionally NOT in shared.env so different agents on the same
# platform can target different WXO tenants.
_tenant_missing=0
for _var in WXO_TENANT_ID WXO_OTEL_EXPORT_URL ENVIRONMENT_NAME; do
    _val="${!_var:-}"
    if [ -z "${_val}" ] || [[ "${_val}" == *"<"* ]]; then
        echo "  ✗ ${_var} is not set in config/${PLATFORM}.env"
        _tenant_missing=1
    fi
done
if [ "${_tenant_missing}" -eq 1 ]; then
    echo ""
    echo "  Edit config/${PLATFORM}.env and re-run."
    exit 1
fi

# ── Banner ─────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║        WXO Unified Agent Analytics Tracing Setup                ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
printf "  Platform    : %s\n" "${PLATFORM}"
printf "  Environment : %s\n" "${ENVIRONMENT_NAME}"
printf "  WXO tenant  : %s\n" "${WXO_TENANT_ID}"
printf "  WXO endpoint: %s\n" "${WXO_OTEL_EXPORT_URL:0:60}..."
echo ""

# ── Dry-run notice ─────────────────────────────────────────────────────────────
if [ "${DRY_RUN}" -eq 1 ]; then
    echo "  --dry-run mode: no changes will be made."
    echo ""
fi

# ── Dispatch ──────────────────────────────────────────────────────────────────
# All env vars are already exported (set -a above), so each child process
# inherits them without re-sourcing config.env.
case "${PLATFORM}" in
    aws)
        exec "${SCRIPT_DIR}/aws/wire_agent.sh" "${PASSTHROUGH_ARGS[@]+"${PASSTHROUGH_ARGS[@]}"}"
        ;;
    azure)
        exec python3 "${SCRIPT_DIR}/azure/wire_agent.py" "${PASSTHROUGH_ARGS[@]+"${PASSTHROUGH_ARGS[@]}"}"
        ;;
    vertex)
        exec "${SCRIPT_DIR}/vertex/wire_agent.sh" "${PASSTHROUGH_ARGS[@]+"${PASSTHROUGH_ARGS[@]}"}"
        ;;
esac
