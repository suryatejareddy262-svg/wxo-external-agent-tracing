#!/usr/bin/env bash
# ============================================================================
# ssm_params.sh
#
# Stores WXO credentials in AWS SSM Parameter Store (SecureString).
# Run this once per tenant when onboarding a new WXO tenant to the account.
# The Lambda reads these at runtime — no hardcoded secrets anywhere.
#
# SSM layout
# ----------
#   /wxo-agent/tenants/<tenant_id>/api_key    ← per-tenant API key
#   /wxo-agent/tenants/<tenant_id>/token_url  ← per-tenant IAM endpoint
#
# Fallback (single-tenant legacy):
#   /wxo-agent/API_KEY    — used when no tenant-specific entry exists
#   /wxo-agent/TOKEN_URL
#
# Why per-tenant keys?
#   Each WXO tenant has its own API key.  Storing a single account-wide
#   API_KEY would prevent different agents from authenticating as their
#   respective tenants.  Keying by tenant_id in SSM gives the Lambda full
#   isolation: it looks up /wxo-agent/tenants/<WXO_TENANT_ID>/api_key at
#   runtime using the WXO_TENANT_ID env var stamped on the agent/harness.
#
# WXO_TENANT_ID and WXO_OTEL_EXPORT_URL are NOT stored in SSM — they are
# injected as env vars directly onto each agent/harness/runtime by the
# wiring scripts (--environment-variables), so each agent can route to a
# different tenant without SSM contention.
#
# Usage:
#   chmod +x ssm_params.sh
#   ./ssm_params.sh
#
#   To register a second tenant, set WXO_TENANT_ID / API_KEY / TOKEN_URL
#   in config/aws.env to the new tenant's values and re-run.
#
# Requires:
#   aws CLI configured with sufficient IAM permissions:
#     ssm:PutParameter
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# Load shared creds (TOKEN_URL) and per-agent tenant vars from aws.env
set -a
source "${SCRIPT_DIR}/config/shared.env"
source "${SCRIPT_DIR}/config/aws.env"
set +a

echo "Storing WXO tenant credentials in AWS SSM Parameter Store..."
echo "Region    : ${AWS_REGION}"
echo "Tenant ID : ${WXO_TENANT_ID}"
echo ""

# Helper — puts a SecureString parameter (overwrites if exists)
put_param() {
    local name="$1"
    local value="$2"
    local description="$3"

    aws ssm put-parameter \
        --region "${AWS_REGION}" \
        --name "${name}" \
        --value "${value}" \
        --type "SecureString" \
        --description "${description}" \
        --overwrite \
        --query "Version" \
        --output text

    echo "  ✓ ${name}"
}

# ============================================================================
# Per-tenant credentials — keyed by WXO_TENANT_ID so the Lambda can look
# up the correct API key for each tenant at runtime.
# ============================================================================

put_param \
    "/wxo-agent/tenants/${WXO_TENANT_ID}/api_key" \
    "${API_KEY}" \
    "WXO API key for tenant ${WXO_TENANT_ID}"

put_param \
    "/wxo-agent/tenants/${WXO_TENANT_ID}/token_url" \
    "${TOKEN_URL}" \
    "IAM token endpoint for tenant ${WXO_TENANT_ID}"

# ============================================================================
# Also write the legacy flat keys so existing Lambda deployments continue
# to work during a rolling upgrade.  The Lambda prefers the per-tenant
# path and falls back to these only when no tenant-specific entry exists.
# ============================================================================

put_param "/wxo-agent/API_KEY"   "${API_KEY}"   "WXO API key (legacy flat — prefer per-tenant path)"
put_param "/wxo-agent/TOKEN_URL" "${TOKEN_URL}" "IAM endpoint (legacy flat — prefer per-tenant path)"

echo ""
echo "Tenant credentials stored."
echo ""
echo "  Per-tenant path : /wxo-agent/tenants/${WXO_TENANT_ID}/"
echo "    api_key        = (SecureString)"
echo "    token_url      = (SecureString)"
echo ""
echo "  Legacy flat keys also updated for backward compatibility."
echo ""
echo "  To add a second tenant: update WXO_TENANT_ID and API_KEY in"
echo "  config/aws.env to the new tenant's values, then re-run this script."
echo ""
echo "Verify with:"
echo "  aws ssm get-parameters-by-path --path /wxo-agent/ --with-decryption --recursive \\"
echo "    --region ${AWS_REGION} --query 'Parameters[*].{Name:Name,Version:Version}' --output table"
